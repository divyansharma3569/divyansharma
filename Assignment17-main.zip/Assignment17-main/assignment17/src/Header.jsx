import React from 'react';

const Header = () => (
  <header>
    <h1>Product Store</h1>
  </header>
);

export default Header;
